
local CopsConnected = 0
local PlayersHarvestingCoke, PlayersTransformingCoke, PlayersSellingCoke, PlayersHarvestingMeth, PlayersTransformingMeth, PlayersSellingMeth, PlayersHarvestingWeed, PlayersTransformingWeed, PlayersSellingWeed, PlayersHarvestingOpium, PlayersSellingkhamr, PlayersTransformingOpium, PlayersSellingOpium = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}


-- Citizen.CreateThread(function()
	-- CopsConnected = 0
	-- local Players = ESX.GetPlayers()
	-- for i = 1, #Players do
		-- local xPlayer = ESX.GetPlayerFromId(Players[i])
		-- if xPlayer.job.name == 'police' or xPlayer.job.name == 'agent' then
			-- CopsConnected = CopsConnected + 1
		-- end
	-- end
-- end)

AddEventHandler('esx:playerLoaded', function(playerId, xPlayer)

	local jobName = xPlayer.job.name

	if jobName == 'police' or jobName == 'agent' then

		CopsConnected = CopsConnected + 1

	end

end)

AddEventHandler('esx:setJob', function(playerID, job, lastJob)

	local lastJobName = lastJob.name

	local newJobName = job.name

    if lastJobName == 'police' or lastJobName == 'agent' then

		CopsConnected = CopsConnected - 1

    end

	if newJobName == 'police' or newJobName == 'agent' then

		CopsConnected = CopsConnected + 1

    end

end)

AddEventHandler("esx:playerDropped", function(playerId, reason, job)
	local xPlayer = ESX.GetPlayerFromId(playerId)
	if xPlayer then
		if xPlayer.job.name == 'police' or xPlayer.job.name == 'agent' then
			CopsConnected = CopsConnected - 1
		end
	end
end)

--[[ SERVER killer
function CountCops()
	local xPlayers = ESX.GetPlayers()

	CopsConnected = 0

	for i = 1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])

		if xPlayer.job.name == 'police' or xPlayer.job.name == 'agent' then
			CopsConnected = CopsConnected + 1
		end
	end

	SetTimeout(120 * 1000, CountCops)
end

CountCops()]]

function DiscordLog (name, title, message, color)
	local DiscordWebHook = "webhooks"

	local embeds = {
		{
			["title"]=title,
			["type"]="rich",
            ["description"] = message,
			["color"] =color,
			["footer"]=  { ["text"]= "سجل بيع الممنوعات",
            ["icon_url"] = "https://cdn.discordapp.com/attachments/931300530393874482/931302251513909348/7fd04efde345f231.png"},
		}
	}

	if message == nil or message == '' then return FALSE end
	PerformHttpRequest(DiscordWebHook, function(err, text, headers) end, 'POST', json.encode({ username = name,embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

function ExtractIdentifiers(src)
    local identifiers = {
        steam = "",
        ip = "",
        discord = "",
        license = "",
        xbl = "",
        live = "",
        fivem = ""
    }

    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local id = GetPlayerIdentifier(src, i)

        if string.find(id, "steam") then
            identifiers.steam = id
        elseif string.find(id, "ip") then
            identifiers.ip = id
        elseif string.find(id, "discord") then
            identifiers.discord = id
        elseif string.find(id, "license") then
            identifiers.license = id
        elseif string.find(id, "xbl") then
            identifiers.xbl = id
        elseif string.find(id, "live") then
            identifiers.live = id
		elseif string.find(id, "fivem") then
            identifiers.fivem = id
        end
    end

    return identifiers
end


-- Weed
local function HarvestWeed(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsWeed then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsWeed))
	--	return
	--end

	SetTimeout(Config.TimeToFarmWeed, function()
		if PlayersHarvestingWeed[source] == true then
			local weed = xPlayer.getInventoryItem('weed')

			if not xPlayer.canCarryItem('weed', weed.weight) then
				xPlayer.showNotification(_U('inv_full_weed'))
			else
				xPlayer.addInventoryItem('weed', 1)
				HarvestWeed(source)
			end

		end
	end)
end

local function TransformWeed(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsWeed then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsWeed))
	--	return
	--end

	SetTimeout(Config.TimeToProcessWeed, function()
		if PlayersTransformingWeed[source] == true then
			local weedQuantity = xPlayer.getInventoryItem('weed').count
			local poochQuantity = xPlayer.getInventoryItem('weed_pooch').count

			if poochQuantity > 40 then
				xPlayer.showNotification(_U('too_many_pouches'))
			elseif weedQuantity < 5 then
				xPlayer.showNotification(_U('not_enough_weed'))
			else
				xPlayer.removeInventoryItem('weed', 5)
				xPlayer.addInventoryItem('weed_pooch', 1)

				TransformWeed(source)
			end
		end
	end)
end


local function SellWeed(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)
  	local Money = 0

	if CopsConnected < Config.RequiredCopsWeed then
		xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsWeed))
		return
	end

	SetTimeout(Config.TimeToSellWeed, function()
		if PlayersSellingWeed[source] == true then
			local poochQuantity = xPlayer.getInventoryItem('weed_pooch').count
			if poochQuantity == 0 then
				xPlayer.showNotification(_U('no_pouches_weed_sale'))
			else
				xPlayer.removeInventoryItem('weed_pooch', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 75, 'بيع حشيش')

				if CopsConnected == 0 then
					Money = 100
				elseif CopsConnected == 1 then
					Money = 1000
				elseif CopsConnected == 2 then
					Money = 1100
				elseif CopsConnected == 3 then
					Money = 1200
				elseif CopsConnected >= 4 then
					Money = 1300
				elseif CopsConnected >= 5 then
					Money = 1400
                elseif CopsConnected >= 6 then
					Money = 1500
                elseif CopsConnected >= 7 then
					Money = 1600
                elseif CopsConnected >= 8 then
					Money = 1700
                elseif CopsConnected >= 9 then
					Money = 1800
                elseif CopsConnected >= 10 then
					Money = 1900
				end
				xPlayer.addAccountMoney('black_money', Money)
				xPlayer.showNotification(_U('sold_one_weed'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog ('بيع الممنوعات', 'بيع شدة حشيش', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				SellWeed(source)
			end
		end
	end)
end

-- Weed

-- Opium
local function HarvestOpium(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsOpium then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsOpium))
	--	return
	--end

	SetTimeout(Config.TimeToFarmOpium, function()
		if PlayersHarvestingOpium[source] == true then
			local opium = xPlayer.getInventoryItem('opium')

			if not xPlayer.canCarryItem('opium', opium.weight) then
				xPlayer.showNotification(_U('inv_full_opium'))
			else
				xPlayer.addInventoryItem('opium', 1)
				HarvestOpium(source)
			end
		end
	end)
end

local function TransformOpium(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsOpium then
		--xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsOpium))
		--return
	--end

	SetTimeout(Config.TimeToProcessOpium, function()
		if PlayersTransformingOpium[source] == true then
			local opiumQuantity = xPlayer.getInventoryItem('opium').count
			local poochQuantity = xPlayer.getInventoryItem('opium_pooch').count

			if poochQuantity > 40 then
				xPlayer.showNotification(_U('too_many_pouches'))
			elseif opiumQuantity < 5 then
				xPlayer.showNotification(_U('not_enough_opium'))
			else
				xPlayer.removeInventoryItem('opium', 5)
				xPlayer.addInventoryItem('opium_pooch', 1)

				TransformOpium(source)
			end
		end
	end)
end

local function SellOpium(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	if CopsConnected < Config.RequiredCopsOpium then
		xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsOpium))
		return
	end

	SetTimeout(Config.TimeToSellOpium, function()
		if PlayersSellingOpium[source] == true then
			local poochQuantity = xPlayer.getInventoryItem('opium_pooch').count
			if poochQuantity == 0 then
				xPlayer.showNotification(_U('no_pouches_opium_sale'))
			else
				xPlayer.removeInventoryItem('opium_pooch', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 150, 'بيع افيون')

				if CopsConnected == 0 then
					Money = 200
				elseif CopsConnected == 1 then
					Money = 2000
				elseif CopsConnected == 2 then
					Money = 2100
				elseif CopsConnected == 3 then
					Money = 2200
				elseif CopsConnected == 4 then
					Money = 2300
				elseif CopsConnected >= 5 then
					Money = 2400
                elseif CopsConnected >= 6 then
					Money = 2500
                elseif CopsConnected >= 7 then
					Money = 1600
                elseif CopsConnected >= 8 then
					Money = 1700
                elseif CopsConnected >= 9 then
					Money = 1800
                elseif CopsConnected >= 10 then
					Money = 2900
				end
				xPlayer.addAccountMoney('black_money', Money)
				xPlayer.showNotification(_U('sold_one_opium'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog ('بيع الممنوعات', 'بيع شدة أفيون', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				SellOpium(source)
			end
		end
	end)
end

-- Opium

-- Coke
local function HarvestCoke(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsCoke then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsCoke))
	--	return
	--end

	SetTimeout(Config.TimeToFarmCoke, function()
		if PlayersHarvestingCoke[source] == true then
			local coke = xPlayer.getInventoryItem('coke')

			if not xPlayer.canCarryItem('coke', coke.weight) then
				xPlayer.showNotification(_U('inv_full_coke'))
			else
				xPlayer.addInventoryItem('coke', 1)
				HarvestCoke(source)
			end
		end
	end)
end

local function TransformCoke(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsCoke then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsCoke))
	--	return
	--end

	SetTimeout(Config.TimeToProcessCoke, function()
		if PlayersTransformingCoke[source] == true then
			local cokeQuantity = xPlayer.getInventoryItem('coke').count
			local poochQuantity = xPlayer.getInventoryItem('coke_pooch').count

			if poochQuantity > 40 then
				xPlayer.showNotification(_U('too_many_pouches'))
			elseif cokeQuantity < 5 then
				xPlayer.showNotification(_U('not_enough_coke'))
			else
				xPlayer.removeInventoryItem('coke', 5)
				xPlayer.addInventoryItem('coke_pooch', 1)

				TransformCoke(source)
			end
		end
	end)
end

local function SellCoke(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	if CopsConnected < Config.RequiredCopsCoke then
		xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsCoke))
		return
	end

	SetTimeout(Config.TimeToSellCoke, function()
		if PlayersSellingCoke[source] == true then
			local poochQuantity = xPlayer.getInventoryItem('coke_pooch').count
			if poochQuantity == 0 then
				xPlayer.showNotification(_U('no_pouches_coke_sale'))
			else
				xPlayer.removeInventoryItem('coke_pooch', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 90, 'بيع كوكايين')

				if CopsConnected == 0 then
					Money = 300
				elseif CopsConnected == 1 then
					Money = 3000
				elseif CopsConnected == 2 then
					Money = 3100
				elseif CopsConnected == 3 then
					Money = 3200
				elseif CopsConnected == 4 then
					Money = 3300
				elseif CopsConnected >= 5 then
					Money = 3400
                elseif CopsConnected >= 6 then
					Money = 3500
                elseif CopsConnected >= 7 then
					Money = 3600
                elseif CopsConnected >= 8 then
					Money = 3700
                elseif CopsConnected >= 9 then
					Money = 3800
                elseif CopsConnected >= 10 then
					Money = 3900
				end
				xPlayer.addAccountMoney('black_money', Money)
				xPlayer.showNotification(_U('sold_one_coke'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog ('بيع الممنوعات', 'بيع شدة كوكايين', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				SellCoke(source)
			end
		end
	end)
end

-- Coke

---------khamr

local function Sellkhamr(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)
	if xPlayer.job.name ~= 'farmer' then xPlayer.showNotification('<font color=red>لايمكنك بيع الخمور يجب عليك اخذ وظيفة المزارع</font>') return end
	if CopsConnected < Config.RequiredCopskhamr then
		xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsOpium))
		return
	end

	SetTimeout(Config.TimeToSellkhamr, function()
		if PlayersSellingkhamr[source] == true then
			local khamrQuantity = xPlayer.getInventoryItem('beer').count
			local khamr2Quantity = xPlayer.getInventoryItem('grand_cru').count
			if khamrQuantity == 0 and khamr2Quantity == 0 then
				xPlayer.showNotification(_U('no_pouches_khamr_sale'))
			elseif khamrQuantity > 0 then
				xPlayer.removeInventoryItem('beer', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 15, 'بيع خمر')

				if CopsConnected == 0 then
					Money = 10
				elseif CopsConnected == 1 then
					Money = 15
				elseif CopsConnected == 2 then
					Money = 25
				elseif CopsConnected == 3 then
					Money = 50
				elseif CopsConnected == 4 then
					Money = 90
				elseif CopsConnected >= 5 then
					Money = 100
                elseif CopsConnected >= 6 then
					Money = 120
                elseif CopsConnected >= 7 then
					Money = 180
                elseif CopsConnected >= 8 then
					Money = 300
                elseif CopsConnected >= 9 then
					Money = 500
                elseif CopsConnected >= 10 then
					Money = 700
				end
				xPlayer.addAccountMoney('black_money', Money)
				xPlayer.showNotification(_U('sold_one_khamr'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog('بيع الممنوعات', 'بيع خمر', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				Sellkhamr(source)
			else
				xPlayer.removeInventoryItem('grand_cru', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 30, 'بيع خمر فاخر')

				if CopsConnected == 0 then
					Money = 10
				elseif CopsConnected == 1 then
					Money = 15
				elseif CopsConnected == 2 then
					Money = 25
				elseif CopsConnected == 3 then
					Money = 50
				elseif CopsConnected == 4 then
					Money = 90
				elseif CopsConnected >= 5 then
					Money = 100
                elseif CopsConnected >= 6 then
					Money = 120
                elseif CopsConnected >= 7 then
					Money = 180
                elseif CopsConnected >= 8 then
					Money = 300
                elseif CopsConnected >= 9 then
					Money = 500
                elseif CopsConnected >= 10 then
					Money = 700
				end
				xPlayer.addAccountMoney('black_money', Money*5)
				xPlayer.showNotification(_U('sold_one_khamr2'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog('بيع الممنوعات', 'بيع خمر فاخر', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				Sellkhamr(source)
			end
		end
	end)
end

-- Meth
local function HarvestMeth(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsMeth then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsMeth))
	--	return
	--end

	SetTimeout(Config.TimeToFarmMeth, function()
		if PlayersHarvestingMeth[source] == true then
			local meth = xPlayer.getInventoryItem('meth')

			if not xPlayer.canCarryItem('meth', meth.weight) then
				xPlayer.showNotification(_U('inv_full_meth'))
			else
				xPlayer.addInventoryItem('meth', 1)
				HarvestMeth(source)
			end
		end
	end)
end

local function TransformMeth(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	--if CopsConnected < Config.RequiredCopsMeth then
	--	xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsMeth))
		--return
	--end

	SetTimeout(Config.TimeToProcessMeth, function()
		if PlayersTransformingMeth[source] == true then
			local methQuantity = xPlayer.getInventoryItem('meth').count
			local poochQuantity = xPlayer.getInventoryItem('meth_pooch').count

			if poochQuantity > 40 then
				xPlayer.showNotification(_U('too_many_pouches'))
			elseif methQuantity < 5 then
				xPlayer.showNotification(_U('not_enough_meth'))
			else
				xPlayer.removeInventoryItem('meth', 5)
				xPlayer.addInventoryItem('meth_pooch', 1)

				TransformMeth(source)
			end
		end
	end)
end

local function SellMeth(source)
	local _source = source
  	local xPlayer = ESX.GetPlayerFromId(_source)

	if CopsConnected < Config.RequiredCopsMeth then
		xPlayer.showNotification(_U('act_imp_police', CopsConnected, Config.RequiredCopsMeth))
		return
	end

	SetTimeout(Config.TimeToSellMeth, function()
		if PlayersSellingMeth[source] == true then
			local poochQuantity = xPlayer.getInventoryItem('meth_pooch').count
			if poochQuantity == 0 then
				xPlayer.showNotification(_U('no_pouches_meth_sale'))
			else
				xPlayer.removeInventoryItem('meth_pooch', 1)
				TriggerEvent('zahya_xplevel:updateCurrentPlayerXP', _source, 'add', 100, 'بيع شبو')

				if CopsConnected == 0 then
					Money = 400
				elseif CopsConnected == 1 then
					Money = 4000
				elseif CopsConnected == 2 then
					Money = 4100
				elseif CopsConnected == 3 then
					Money = 4200
				elseif CopsConnected == 4 then
					Money = 4300
				elseif CopsConnected == 5 then
					Money = 4400
				elseif CopsConnected >= 6 then
					Money = 4500
                elseif CopsConnected >= 7 then
					Money = 4600
                elseif CopsConnected >= 8 then
					Money = 4700
                elseif CopsConnected >= 9 then
					Money = 4800
                elseif CopsConnected >= 10 then
					Money = 4900
				end
				xPlayer.addAccountMoney('black_money', Money)
				xPlayer.showNotification(_U('sold_one_meth'))

				local ids = ExtractIdentifiers(source)
				_discordID ="<@" ..ids.discord:gsub("discord:", "")..">"
				_identifierID ="**identifier:  ** " ..xPlayer.identifier..""
				DiscordLog ('بيع الممنوعات', 'بيع شدة شبو', ''..xPlayer.getName()..'\n'.._discordID..'\n'.._identifierID..'\nكسب أموال قذرة: $'..Money)

				SellMeth(source)
			end
		end
	end)
end

CanSellDrugs = false

RegisterNetEvent('esx_drugs:togglePromotion', function()
    if CanSellDrugs == false then
        CanSellDrugs = true
        TriggerEvent("esx_misc:NoCrimetimeDrugs", CanSellDrugs, source)
    else
        CanSellDrugs = false
        TriggerEvent("esx_misc:NoCrimetimeDrugs", CanSellDrugs, source)
    end
end)

RegisterServerEvent('esx_K6dr2H2ugs:Server') -- esx_drugs:Server
AddEventHandler('esx_K6dr2H2ugs:Server', function(Action, drug)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	--# start Harvest The drug
	if Action == 'startHarvest' then
    if drug == 'Weed' then
	PlayersHarvestingWeed[_source] = true
	HarvestWeed(_source)
	elseif drug == 'Opium' then
	PlayersHarvestingOpium[_source] = true
	HarvestOpium(_source)
	elseif drug == 'Coke' then
	PlayersHarvestingCoke[_source] = true
	HarvestCoke(_source)
	elseif drug == 'Meth' then
	PlayersHarvestingMeth[_source] = true
	HarvestMeth(_source)
	end
	xPlayer.showNotification(_U('pickup_in_prog'))
	--# start Trans From drug
	elseif Action == 'startTransFromDrug' then
	if drug == 'Weed' then
	PlayersTransformingWeed[_source] = true
	TransformWeed(_source)
	elseif drug == 'Opium' then
	PlayersTransformingOpium[_source] = true
	TransformOpium(_source)
	elseif drug == 'Coke' then
	PlayersTransformingCoke[_source] = true
	TransformCoke(_source)
	elseif drug == 'Meth' then
	PlayersTransformingMeth[_source] = true
	TransformMeth(_source)
	end
	xPlayer.showNotification(_U('packing_in_prog'))
	--# start Sell The drug
	elseif Action == 'startSell' then
		if CanSellDrugs == false then
			if drug == 'Weed' then
			PlayersSellingWeed[_source] = true
			SellWeed(_source)
			elseif drug == 'Opium' then
			PlayersSellingOpium[_source] = true
			SellOpium(_source)
			elseif drug == 'khamr' then
				PlayersSellingkhamr[_source] = true
			Sellkhamr(_source)
			elseif drug == 'Coke' then
			PlayersSellingCoke[_source] = true
			SellCoke(_source)

			elseif drug == 'Meth' then
			PlayersSellingMeth[_source] = true
			SellMeth(_source)
			end
			xPlayer.showNotification(_U('sale_in_prog'))
		else
			xPlayer.showNotification('<SPAN STYLE="COLOR:RED;">لايمكنك بيع الممنوعات في وقت منع التهريب</SPAN>')
		end
	--# Stop All
	elseif Action == 'Stop' then
	PlayersHarvestingWeed[_source] = false
	PlayersHarvestingOpium[_source] = false
	PlayersHarvestingCoke[_source] = false
	PlayersHarvestingMeth[_source] = false

	PlayersTransformingWeed[_source] = false
	PlayersTransformingOpium[_source] = false
	PlayersTransformingCoke[_source] = false
	PlayersTransformingMeth[_source] = false

	PlayersSellingkhamr[_source] = false
	PlayersSellingWeed[_source] = false
	PlayersSellingOpium[_source] = false
	PlayersSellingCoke[_source] = false
	PlayersSellingMeth[_source] = false
	end
end)

-- Meth
RegisterServerEvent('esx_K20drugs:GetUserInventory_H') -- esx_drugs:GetUserInventory
AddEventHandler('esx_K20drugs:GetUserInventory_H', function(currentZone)
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)

	TriggerClientEvent('esx_drugs:ReturnInventory', _source, xPlayer.getInventoryItem('coke').count, xPlayer.getInventoryItem('coke_pooch').count,xPlayer.getInventoryItem('meth').count, xPlayer.getInventoryItem('meth_pooch').count, xPlayer.getInventoryItem('weed').count, xPlayer.getInventoryItem('weed_pooch').count, xPlayer.getInventoryItem('opium').count, xPlayer.getInventoryItem('opium_pooch').count,xPlayer.job.name, currentZone)
end)

-- ESX.RegisterUsableItem('weed', function(source)
-- 	local _source = source
--   	local xPlayer = ESX.GetPlayerFromId(_source)

-- 	xPlayer.removeInventoryItem('weed', 1)

-- 	TriggerClientEvent('esx_drugs:onPot', _source)
-- 	xPlayer.showNotification(_U('used_one_weed'))
-- end)

-- ESX.RegisterUsableItem('meth', function(source)
-- 	local _source = source
-- 	local xPlayer = ESX.GetPlayerFromId(_source)

-- 	xPlayer.removeInventoryItem('meth', 1)

-- 	TriggerClientEvent('esx_drugs:onMeth', _source)
-- 	xPlayer.showNotification(_U('used_one_meth'))
-- end)

-- ESX.RegisterUsableItem('opium', function(source)
-- 	local _source = source
-- 	local xPlayer = ESX.GetPlayerFromId(_source)

-- 	xPlayer.removeInventoryItem('opium', 1)

-- 	TriggerClientEvent('esx_drugs:onOpium', _source)
-- 	xPlayer.showNotification(_U('used_one_opium'))
-- end)

-- ESX.RegisterUsableItem('coke', function(source)
-- 	local _source = source
-- 	local xPlayer = ESX.GetPlayerFromId(_source)

-- 	xPlayer.removeInventoryItem('coke', 1)

-- 	TriggerClientEvent('esx_drugs:onCoke', _source)
-- 	xPlayer.showNotification(_U('used_one_coke'))
-- end)

ESX.RegisterServerCallback('esx_drugs:getOnlinePolices', function(source, cb)
	local _source  = source
	local xPlayers = ESX.GetPlayers()
	local cops = 0

	  for i=1, #xPlayers, 1 do

		  local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		  if xPlayer.job.name == 'police' or xPlayer.job.name == 'agent' then
		  cops = cops + 1
		  end
	  end
	  Wait(25)
	  cb(cops)
  end)
