# esx_illegal_drugs
This is the old esx_drugs which contain opium, weed, cocaine & meth.  
This was a fork from [esx_drugs](https://github.com/ESX-Org/esx_drugs) but they changed the way they do drugs and they only use weed now.  
This is why this is not a fork.  

**REQUIREMENTS**
This version is modified to use [FiveMIPL](https://github.com/esx-community/fivem-ipl)  
You will also need [Teleport Script](https://github.com/XxFri3ndlyxX/Teleport)   
You will also need the latest [esx_policejob](https://github.com/ESX-Org/esx_policejob)  &  latest [es_extended](https://github.com/ESX-Org/es_extended)         


**INSTALATION**  
Put resource esx_illegal_drugs in your server 
Import esx_illegal_drugs.sql in your database  
Add this in your server.cfg:  
```start esx_illegal_drugs```   
If your getting errors, It's most likely that you have your start order wrong. 
This is an example of a fresh server with all their dependency with the correct order. Make sure yours look similiar to that
```
### [ESSENTIALS] ###
start mysql-async
start essentialmode
start esplugin_mysql
start es_extended
start async
start es_ui
start es_admin2
start esx_kashacters
start esx_identity
start skinchanger
start esx_skin
start instance
start esx_datastore
start esx_addonaccount
start esx_addoninventory
start cron
start esx_menu_default
start esx_menu_list
start esx_menu_dialog
start esx_license
start esx_billing
start esx_society
start esx_policejob
start esx_ambulancejob
start esx_vehicleshop
start esx_illegal_drugs
start fivem-ipl
start Teleport
```

**CONFIGURATION**
Keybind is C on keyboard or R3 on controller.  
Make sure your not a cop when attempting to gather/process/sell drugs.
Make sure that you set the number of cop desired in the config file.

**HOW THIS WORKS**  
Go to Weed,meth,opium or coke farm.  
Use the teleport script to get to the harvesting location.  
Start harvesting. (You can harvest up to 420 max, each 1 weed is = to 1G)  
Start processing the selected drug.  
(This will remove 28G from your inventory and will add 1 bag which will contain 28G.  You can process 420G to get a max of 15 bag)     
Now you can go and sell your drug.    

**TODO* Adding animation**     

**Screenshot**  
<a href="https://imgur.com/hb3yEjZ"><img src="https://i.imgur.com/hb3yEjZ.jpg" title="source: imgur.com" /></a>
<a href="https://imgur.com/kGKoSZS"><img src="https://i.imgur.com/kGKoSZS.jpg" title="source: imgur.com" /></a>
<a href="https://imgur.com/NL90eRb"><img src="https://i.imgur.com/NL90eRb.jpg" title="source: imgur.com" /></a>
<a href="https://imgur.com/AJ35TBN"><img src="https://i.imgur.com/AJ35TBN.jpg" title="source: imgur.com" /></a>     
**VIDEO**
<a href="https://streamable.com/f6dcn"><img src="https://i.imgur.com/hb3yEjZ.jpg" title="source: imgur.com" /></a>        
        

Legal
License

Copyright (C) 2015-2018 Jérémie N'gadi

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.
