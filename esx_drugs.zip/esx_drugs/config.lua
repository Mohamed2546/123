Config = {

}

Config.RequiredPolices = 0


Config.MarkerType   = 1 -- Marker visible or not. -1 = hiden  Set to 1 for a visible marker. To have a list of avaible marker go to https://docs.fivem.net/game-references/markers/
Config.DrawDistance = 100.0 --Distance where the marker be visible from
Config.ZoneSize     = {x = 5.0, y = 5.0, z = 1.0} -- Size of the marker
Config.MarkerColor  = {r = 0, g = 255, b = 0} --Color of the marker


Config.ShowBlips   = true  --markers visible on the map? (false to hide the markers on the map)

Config.RequiredCopsCoke  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell coke
Config.RequiredCopsMeth  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell meth
Config.RequiredCopsWeed  = 0 --Ammount of cop that need to be online to be able to harvest/process/sell weed
Config.RequiredCopsOpium = 0 --Ammount of cop that need to be online to be able to harvest/process/sell opium
Config.RequiredCopskhamr = 0

Config.TimeToSellkhamr     = 2  * 1000

Config.TimeToFarmWeed     = 1  * 1000 -- Ammount of time to harvest weed
Config.TimeToProcessWeed  = 2  * 1000 -- Ammount of time to process weed
Config.TimeToSellWeed     = 2  * 1000 -- Ammount of time to sell weed

Config.TimeToFarmOpium    = 2  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessOpium = 2  * 1000 -- Ammount of time to process coke
Config.TimeToSellOpium    = 2  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmCoke     = 1  * 1000 -- Ammount of time to harvest coke
Config.TimeToProcessCoke  = 2  * 1000 -- Ammount of time to process coke
Config.TimeToSellCoke     = 2  * 1000 -- Ammount of time to sell coke

Config.TimeToFarmMeth     = 1  * 1000 -- Ammount of time to harvest meth
Config.TimeToProcessMeth  = 2 * 1000 -- Ammount of time to process meth
Config.TimeToSellMeth     = 2  * 1000 -- Ammount of time to sell meth

Config.Locale = 'en'

Config.Prices = {
	weed_pooch 	= 500,
	coke_pooch 	= 600,
	opium_pooch = 1000,
	meth_pooch 	= 700,
	beer = 50
}

Config.Xp = {
	weed_pooch 	= 20,
	coke_pooch 	= 20,
	opium_pooch = 20,
	meth_pooch 	= 20,
	beer = 2
}

Config.Zones = { --
	[1]	 = { 
		khamr = {x = 931.4092,	y = -3082.6360,	z = 11.5070, 	name = 'ﺮﻤﺧ ﺐﻳﺮﻬﺗ',		sprite = 93,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280, 	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 1020.36,	y = -3034.21,	z = 5.9,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 1121.35,	y = -2981.84,	z =5.9,		name = _U('coke_dealer'),		sprite = 501,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.8972,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 851.6,		y = -3097.54,	z = 5.9,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 4445.9141,	y = -4444.4995,	z = 6.2768,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},
	
	[2]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 59.6, y = -2491.91, z = 6.01,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = -23.36, y = -2479.07, z = 6.01,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.8972,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = -93.82, y = -2488.47, z = 6.01,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 4445.9141,	y = -4444.4995,	z = 6.2768,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = -163.55, y = -2374.02, z = 9.32,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},
	
	[3]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = -1238.31, y = -2239.78, z = 13.94,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = -1156.27, y = -2571.55, z = 13.94,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.8972,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = -1184.34, y = -2658.43, z = 13.94,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 4445.9141,	y = -4444.4995,	z = 6.2768,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = -1337.52, y = -2619.07, z = 13.94,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},
	
	[4]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 1020.36,	y = -3034.21,	z = 5.9,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 1121.35,	y = -2981.84,	z =5.9,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.8972,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 851.6,		y = -3097.54,	z = 5.9,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 4445.9141,	y = -4444.4995,	z = 6.2768,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},
	
	[11]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 1020.36,	y = -3034.21,	z = 5.9,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 1121.35,	y = -2981.84,	z =5.9,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.89728,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 851.6,		y = -3097.54,	z = 5.9,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = 556.61,	y = -2998.79,	z = 6.04,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},

	[12]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 246.50,	y = -3121.63,	z = 5.79,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 1121.35,	y = -2981.84,	z =5.9,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.89728,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 851.6,		y = -3097.54,	z = 5.9,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = 268.26,	y = -3205.22,	z = 7.29,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},

	[13]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 288.23,	y = -2878.58,	z = 5.86,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 556.61,	y = -2998.79,	z = 6.04,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.89728,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 1034.24,		y = -3033.86,	z = 5.90,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = -155.00,	y = -2412.12,	z = 6.00,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},

	[14]	 = {
		WeedField = {x = 5394.5874,	y = -5275.5015,	z = 34.5280,	name = _U('weed_field'),		sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 1 ]]WeedProcessing =	{x = 5092.7964,	y = -4683.4497,	z = 1.4678,	name = _U('weed_processing'),	sprite = 496,	color = 52,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		WeedDealer = {x = 288.23,	y = -2878.58,	z = 5.86,	name = _U('weed_dealer'),		sprite = 496,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		CokeField = {x = 5304.5786,	y = -5245.8062,  	z = 31.5669,	name = _U('coke_field'),		sprite = 501,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 2 ]] CokeProcessing =	{x = 5000.3623,	y = -5164.5654,	z = 1.8446,	name = _U('coke_processing'),	sprite = 478,	color = 40,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		CokeDealer = {x = 556.61,	y = -2998.79,	z = 6.04,		name = _U('coke_dealer'),		sprite = 478,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},	
		
		MethField = {x = 5339.2329,	y = -5338.6660,	z = 37.9212,	name = _U('meth_field'),		sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 3 ]] MethProcessing =	{x = 5065.7593,	y = -4590.7607,	z = 1.89728,	name = _U('meth_processing'),	sprite = 499,	color = 26,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		MethDealer = {x = 1034.24,		y = -3033.86,	z = 5.90,	name = _U('meth_dealer'),		sprite = 499,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true},
		
		OpiumField = {x = 5211.2559,	y = -5184.0552,	z = 11.9846,	name = _U('opium_field'),		sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		--[[ 4 ]] OpiumProcessing =	{x = 937.96,	y = -3034.37,	z = 5.9,	name = _U('opium_processing'),	sprite = 51,	color = 60,   MarkerType = 1,   ZoneSize = {x = 5.0, y = 5.0, z = 1.0},   MarkerColor = {r = 100, g = 204, b = 100},   Opacity = 100,   Rotate = false},
		OpiumDealer = {x = -155.00,	y = -2412.12,	z = 6.00,	name = _U('opium_dealer'),		sprite = 51,	color = 75,   MarkerType = 29,  ZoneSize = {x = 1.0, y = 1.0, z = 1.0},   MarkerColor = {r = 255, g = 0, b = 0},       Opacity = 100,   Rotate = true}
	},
}

Config.DisableBlip = false -- Set to true to disable blips. False to enable them.
Config.Map = { 

  {name="Coke Farm Entrance",    color=4, scale=0.8, id=501, x=47.842,     y=3701.961,   z=40.722},
  {name="Coke Farm",             color=4, scale=0.8, id=501, x=1093.139,   y=-3195.673,  z=-39.131},
  {name="Coke Processing",       color=4, scale=0.8, id=501, x = 5000.3623,	y = -5164.5654,	z = 1.8446},
  {name="Coke Sales",            color=3, scale=0.8, id=501, x=959.117,    y=-121.055,   z=74.963},
  {name="Meth Farm Entrance",    color=6, scale=0.8, id=499, x=1386.659,   y=3622.805,   z=35.012},
  {name="Meth Farm",             color=6, scale=0.8, id=499, x=1005.721,   y=-3200.301,  z=-38.519},
  {name="Meth Processing",       color=6, scale=0.8, id=499, x = 5065.7593,	y = -4590.7607,	z = 1.8972},
  {name="Meth Sales",            color=3, scale=0.8, id=499, x=7.981,      y=6469.067,   z=31.528},
  {name="Opium Farm Entrance",   color=6, scale=0.8, id=403, x=2433.804,   y=4969.196,   z=42.348},
  {name="Opium Farm",            color=6, scale=0.8, id=403, x=2433.804,   y=4969.196,   z=42.348},
  {name="Opium Processing",      color=6, scale=0.8, id=403, x = 4445.9141,	y = -4444.4995,	z = 6.2768},
  {name="Opium Sales",           color=3, scale=0.8, id=403, x=-3155.608,  y=1125.368,   z=20.858},
 -- {name="Weed Farm Entrance",    color=2, scale=0.8, id=140, x=2221.858,   y=5614.81,    z=54.902},
  {name="ﺶﻴﺸﺤﻟﺍ ﺔﻋﺭﺰﻣ",             color=2, scale=0.8, id=140, x = 5394.5874,	y = -5275.5015,	z = 34.5280,},
  {name="ﺶﻴﺸﺤﻟﺍ ﻊﻴﻨﺼﺗ",       color=2, scale=0.8, id=140, x = 5092.7964,	y = -4683.4497,	z = 1.4678},
  {name="ﺶﻴﺸﺤﻟﺍ ﺮﺟﺎﺗ",            color=3, scale=0.8, id=140, x = 1020.36,	y = -3034.21,	z = 5.9}

} 